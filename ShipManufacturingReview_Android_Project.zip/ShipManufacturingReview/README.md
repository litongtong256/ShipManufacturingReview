# 船舶机械智能制造复习助手（Android）

这是基于你上传的 Word 题库制作的原生 Android 项目初版。

## 当前功能
- 离线题库浏览
- 六类题型筛选
- 搜索题目、答案和考点
- 点击题目后翻看参考答案
- 收藏题目（保存在本机）
- 计算题与分析题保留题库中的文字步骤、考点及提取到的题目配图

## 题库导入说明
- 从原 DOCX 文档抽取段落内容，生成 `app/src/main/assets/question_bank.json`
- 原文中的“待核对”与缺失答案提示按原文保留
- 题目配图已提取到 Android drawable 资源，并在题目详情中展示

## 如何生成 APK
1. 在电脑安装 Android Studio（建议最新稳定版）。
2. 选择 Open，打开本项目文件夹 `ShipManufacturingReview`。
3. 等待 Gradle Sync 完成。
4. 连接 Android 手机并开启 USB 调试，或使用模拟器。
5. 选择 Build > Build Bundle(s) / APK(s) > Build APK(s)。
6. APK 通常生成在 `app/build/outputs/apk/debug/app-debug.apk`。

## 技术
Kotlin + Jetpack Compose + Material 3；题库和收藏可离线使用。
