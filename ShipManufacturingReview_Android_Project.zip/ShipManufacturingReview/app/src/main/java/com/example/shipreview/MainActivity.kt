package com.example.shipreview

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject

data class Question(
    val id: String, val category: String, val subcategory: String,
    val number: String, val question: String, val answer: String,
    val notes: String, val reference: String, val images: List<String>
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val json = assets.open("question_bank.json").bufferedReader().use { it.readText() }
        val root = JSONObject(json)
        val array = root.getJSONArray("questions")
        val questions = (0 until array.length()).map { i ->
            val o = array.getJSONObject(i)
            Question(
                o.optString("id"), o.optString("category"), o.optString("subcategory"),
                o.optString("number"), o.optString("question"), o.optString("answer"),
                o.optString("notes"), o.optString("reference"), (0 until o.optJSONArray("images").length()).map { k -> o.optJSONArray("images").getString(k).substringAfterLast("/").substringBeforeLast(".") }
            )
        }
        val prefs = getSharedPreferences("review", MODE_PRIVATE)
        setContent { ReviewApp(questions, prefs) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReviewApp(questions: List<Question>, prefs: android.content.SharedPreferences) {
    val categories = listOf("全部", "填空题", "判断题", "问答题", "计算题", "分析题", "名词解释")
    var selectedCategory by remember { mutableStateOf("全部") }
    var search by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<Question?>(null) }
    var showAnswer by remember { mutableStateOf(false) }
    var favorites by remember { mutableStateOf(prefs.getStringSet("favorites", emptySet())?.toSet() ?: emptySet()) }
    var tab by remember { mutableStateOf(0) }

    val filtered = questions.filter {
        (selectedCategory == "全部" || it.category == selectedCategory) &&
        (tab != 1 || favorites.contains(it.id)) &&
        (search.isBlank() || it.question.contains(search, true) || it.answer.contains(search, true) || it.notes.contains(search, true))
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFF245B50),
            secondary = Color(0xFFB77C45),
            background = Color(0xFFF5F4EF),
            surface = Color(0xFFFFFEFA)
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            if (selected != null) {
                val q = selected!!
                Column(Modifier.fillMaxSize().padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("‹ 返回", Modifier.clickable { selected = null; showAnswer = false }, color = MaterialTheme.colorScheme.primary, fontSize = 18.sp)
                        Spacer(Modifier.weight(1f))
                        Text(q.category, color = Color.Gray)
                    }
                    Spacer(Modifier.height(22.dp))
                    Text("${q.category} · ${q.number}", color = MaterialTheme.colorScheme.secondary, fontSize = 13.sp)
                    Spacer(Modifier.height(12.dp))
                    Text(q.question, fontSize = 21.sp, fontWeight = FontWeight.SemiBold, lineHeight = 31.sp)
                    val context = androidx.compose.ui.platform.LocalContext.current
                    q.images.forEach { imageName ->
                        val imageId = remember(imageName) { context.resources.getIdentifier(imageName, "drawable", context.packageName) }
                        if (imageId != 0) {
                            Spacer(Modifier.height(12.dp))
                            androidx.compose.foundation.Image(
                                painter = androidx.compose.ui.res.painterResource(imageId),
                                contentDescription = "题目配图",
                                modifier = Modifier.fillMaxWidth().heightIn(max = 260.dp)
                            )
                        }
                    }
                    Spacer(Modifier.height(24.dp))
                    Button(onClick = { showAnswer = !showAnswer }, modifier = Modifier.fillMaxWidth()) {
                        Text(if (showAnswer) "收起答案" else "查看参考答案")
                    }
                    if (showAnswer) {
                        Spacer(Modifier.height(18.dp))
                        Text("参考答案", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.height(8.dp))
                        Text(q.answer.ifBlank { "原文件未提供明确答案。" }, fontSize = 16.sp, lineHeight = 25.sp)
                        if (q.notes.isNotBlank()) {
                            Spacer(Modifier.height(14.dp))
                            Text("考点：${q.notes}", color = Color(0xFF8A633A))
                        }
                        if (q.reference.isNotBlank()) {
                            Spacer(Modifier.height(6.dp))
                            Text("资料位置：${q.reference}", color = Color.Gray, fontSize = 12.sp)
                        }
                    }
                    Spacer(Modifier.weight(1f))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(onClick = {
                            val next = if (favorites.contains(q.id)) favorites - q.id else favorites + q.id
                            favorites = next
                            prefs.edit().putStringSet("favorites", next).apply()
                        }, modifier = Modifier.weight(1f)) {
                            Text(if (favorites.contains(q.id)) "★ 已收藏" else "☆ 收藏")
                        }
                        Button(onClick = {
                            val idx = questions.indexOf(q)
                            selected = questions.getOrNull((idx + 1) % questions.size)
                            showAnswer = false
                        }, modifier = Modifier.weight(1f)) { Text("下一题 →") }
                    }
                }
            } else {
                Column(Modifier.fillMaxSize()) {
                    Column(Modifier.padding(horizontal = 18.dp, vertical = 16.dp)) {
                        Text("船舶机械智能制造", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Color(0xFF214D43))
                        Text("考试复习助手 · 离线题库", color = Color.Gray, fontSize = 13.sp)
                        Spacer(Modifier.height(16.dp))
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(14.dp)).padding(13.dp)) {
                            Text("⌕  ", color = Color.Gray)
                            BasicTextField(value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, decorationBox = { inner ->
                                if (search.isEmpty()) Text("搜索题目、答案或考点…", color = Color.Gray)
                                inner()
                            })
                        }
                        Spacer(Modifier.height(14.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(selected = tab == 0, onClick = { tab = 0 }, label = { Text("全部题目") })
                            FilterChip(selected = tab == 1, onClick = { tab = 1 }, label = { Text("我的收藏 ★") })
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("题型分类", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Spacer(Modifier.height(8.dp))
                        LazyColumn(contentPadding = PaddingValues(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                            item {
                                Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                    categories.chunked(3).forEach { row ->
                                        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                            row.forEach { c ->
                                                FilterChip(
                                                    selected = selectedCategory == c,
                                                    onClick = { selectedCategory = c },
                                                    label = { Text(c, fontSize = 12.sp) }
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                            item {
                                Text("${filtered.size} 道题目", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(vertical = 4.dp))
                            }
                            items(filtered, key = { it.id }) { q ->
                                Card(
                                    modifier = Modifier.fillMaxWidth().clickable { selected = q; showAnswer = false },
                                    colors = CardDefaults.cardColors(containerColor = Color.White),
                                    shape = RoundedCornerShape(15.dp)
                                ) {
                                    Column(Modifier.padding(15.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text("${q.category} · ${q.number}", color = Color(0xFF9B7047), fontSize = 12.sp)
                                            Spacer(Modifier.weight(1f))
                                            if (favorites.contains(q.id)) Text("★", color = Color(0xFFB77C45))
                                        }
                                        Spacer(Modifier.height(7.dp))
                                        Text(q.question, fontWeight = FontWeight.Medium, fontSize = 15.sp, lineHeight = 22.sp, maxLines = 4)
                                        Spacer(Modifier.height(7.dp))
                                        Text("点击查看答案  →", color = Color(0xFF245B50), fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
